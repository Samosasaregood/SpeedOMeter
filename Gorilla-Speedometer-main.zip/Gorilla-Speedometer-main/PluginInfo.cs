﻿
namespace Spedometer
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    class PluginInfo
    {
        public const string GUID = "com.tyre.gorillatag.spedometer";
        public const string Name = "Spedometer";
        public const string Version = "1.0.0";
    }
}
